Roadmap
=======

* Quantized CPU inference
* Mixed-precision inference
* Improved Mali and PowerVR support
* More Ops
* Improved host/x86 performance
* Android NN integration

*Last updated: June 27, 2018*
