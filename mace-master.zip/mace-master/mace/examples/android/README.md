Android Demo
=============

How to build
---------------

```sh
cd mace/exampls/android
./build.sh
```

Pre-built APK
--------------
Pre-built Android APK can be downloaded [here](https://cnbj1.fds.api.xiaomi.com/mace/demo/mace_android_demo.apk).