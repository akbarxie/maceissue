Release Notes
=====

v0.6.0 (2018-04-04)
------
1. Change mace header interfaces, only including necessary methods.

v0.6.2 (2018-05-17)
------
* Return status instead of abort when allocate failed

v0.6.3 (2018-05-21)
------
1. support `float` `data_type` when running in GPU

v0.7.0 (2018-05-18)
------
1. Change interface that report error type
2. Improve CPU performance
3. Merge CPU/GPU engine to on

v0.8.0 (2018-05-31)
------
1. Change build and run tools
2. Handle runtime failure
